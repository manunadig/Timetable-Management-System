package com.example.timetablemanagementsystem;

public class Ttl_list {

    int sem;
    String subCode;
    String subName;
    String mon;
    String tue;
    String wed;
    String thu;
    String fri;
    String sat;
}
