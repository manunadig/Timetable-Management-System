package com.example.timetablemanagementsystem;

public class global {
    public static String BASE_URL = "http://10.60.216.77:9001" ;
}
